// ACCORDAE · script partagé
(function () {
  var body = document.body;
  var burger = document.querySelector('.burger');
  var nav = document.getElementById('nav');

  // Menu burger
  if (burger && nav) {
    burger.addEventListener('click', function () {
      var open = body.classList.toggle('nav-open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      burger.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
    });
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a')) { body.classList.remove('nav-open'); burger.setAttribute('aria-expanded', 'false'); }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && body.classList.contains('nav-open')) { body.classList.remove('nav-open'); burger.setAttribute('aria-expanded', 'false'); burger.focus(); }
    });
  }

  // Page active (filet de sécurité si aria-current absent)
  var page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav a').forEach(function (a) {
    if (a.getAttribute('href') === page && !a.hasAttribute('aria-current')) a.setAttribute('aria-current', 'page');
  });

  // Année du pied de page
  document.querySelectorAll('[data-annee]').forEach(function (el) { el.textContent = new Date().getFullYear(); });

  // Formulaire de contact (envoi Formspree sans rechargement, repli natif sinon)
  var form = document.querySelector('form[data-formspree]');
  if (form && window.fetch && window.FormData) {
    var status = form.querySelector('.form__status');
    form.addEventListener('submit', function (e) {
      if (form.action.indexOf('A_REMPLACER') !== -1) return; // identifiant non configuré : envoi natif
      e.preventDefault();
      var btn = form.querySelector('button[type="submit"]');
      btn.disabled = true;
      status.textContent = 'Envoi en cours\u2026';
      status.removeAttribute('data-ok');
      fetch(form.action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } })
        .then(function (r) {
          if (!r.ok) throw new Error();
          form.reset();
          status.dataset.ok = '1';
          status.textContent = 'Merci\u00a0! Votre message est bien parti. Réponse sous 48\u00a0h.';
        })
        .catch(function () {
          status.dataset.ok = '0';
          status.textContent = 'Oups, l\u2019envoi n\u2019a pas fonctionné. Écrivez-moi directement à contact@accordae.com.';
        })
        .then(function () { btn.disabled = false; });
    });
  }
})();
